# Utils package initialization
from .exceptions import CustomHTTPException

__all__ = ["CustomHTTPException"]
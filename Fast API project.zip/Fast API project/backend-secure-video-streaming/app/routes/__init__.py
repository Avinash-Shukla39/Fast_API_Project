# Routes package initialization
from .video_routes import router as video_router

__all__ = ["video_router"]
export { default as Home } from './pages/Home';
export { default as Upload } from './pages/Upload';
export { default as Stream } from './pages/Stream';